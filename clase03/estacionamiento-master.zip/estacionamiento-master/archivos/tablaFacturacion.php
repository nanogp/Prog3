 <table border=1><th> patente </th><th> Importe </th><tr> <td> abc123</td> <td>   $300
</td> </tr><tr> <td> rte456</td> <td>   $9825
</td> </tr> </table>