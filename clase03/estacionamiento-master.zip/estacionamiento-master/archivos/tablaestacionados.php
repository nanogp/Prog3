 <table border=1><th> patente </th><th> Ingreso</th><tr> <td> asd345 </td> <td> 2015-09-16 00:51:17
</td> </tr> </table>